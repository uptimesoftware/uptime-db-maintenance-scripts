CREATE OR REPLACE
PROCEDURE trim_uptime_data IS
	retaindays NUMBER;
	trimdate DATE;
	trimid NUMBER;
	rownum NUMBER;
	samplesnum NUMBER;
	remainder NUMBER;
	iterations NUMBER;
	i NUMBER;
	sql_stmt VARCHAR2(150);
	
	--CURSOR cur_perftable IS SELECT table_name FROM user_tables WHERE (table_name LIKE 'PERFORMANCE_%') AND table_name != 'PERFORMANCE_SAMPLE'; 
	CURSOR cur_edtable IS SELECT table_name FROM user_tables WHERE (table_name LIKE 'ERDC_%_DATA');
			
	BEGIN		
		retaindays :=365; -- 1 year retention period.  For last 3 months set to 90 
		rownum := 10000;   -- # of rows to delete at a time.  Setting this too high may cause redo logs to get full 		
		
		trimdate := (sysdate-retaindays);		
		SELECT MAX(id) INTO trimid FROM performance_sample WHERE sample_time < trimdate;
				
		IF trimid IS NOT NULL THEN								
			DBMS_OUTPUT.put_line('Keeping ' || retaindays || ' days of historical data.  Data older than ' || trimdate || ' will be trimmed out ' || rownum || ' rows at a time.');
			
			-- BEGIN PERFORMANCE TABLE TRIM BLOCK			
			-- trim performance_aggregate
			i := 0;
			SELECT count(*) INTO samplesnum FROM performance_sample ps, performance_aggregate px WHERE ps.sample_time < trimdate and px.sample_id=ps.id; 
			remainder := mod(samplesnum, rownum);
			iterations := ((samplesnum - remainder)/rownum) + 1;			
			WHILE i < iterations LOOP
				DBMS_OUTPUT.put_line('Trimming performance_aggregate table iteration ' || (i+1) || ' of ' || iterations);
				sql_stmt := 'DELETE FROM performance_aggregate WHERE sample_id < ' || trimid || ' AND ROWNUM <= ' || rownum;
				--DBMS_OUTPUT.put_line(sql_stmt);
				EXECUTE IMMEDIATE sql_stmt;
				COMMIT;
				i := i + 1;
			END LOOP;
			
			-- trim performance_cpu
			i := 0;
			SELECT count(*) INTO samplesnum FROM performance_sample ps, performance_cpu px WHERE ps.sample_time < trimdate and px.sample_id=ps.id; 
			remainder := mod(samplesnum, rownum);
			iterations := ((samplesnum - remainder)/rownum) + 1;			
			WHILE i < iterations LOOP
				DBMS_OUTPUT.put_line('Trimming performance_cpu table iteration ' || (i+1) || ' of ' || iterations);
				sql_stmt := 'DELETE FROM performance_cpu WHERE sample_id < ' || trimid || ' AND ROWNUM <= ' || rownum;				
				EXECUTE IMMEDIATE sql_stmt;
				COMMIT;
				i := i + 1;
			END LOOP;

			-- trim performance_disk
			i := 0;
			SELECT count(*) INTO samplesnum FROM performance_sample ps, performance_disk px WHERE ps.sample_time < trimdate and px.sample_id=ps.id; 
			remainder := mod(samplesnum, rownum);
			iterations := ((samplesnum - remainder)/rownum) + 1;			
			WHILE i < iterations LOOP
				DBMS_OUTPUT.put_line('Trimming performance_disk table iteration ' || (i+1) || ' of ' || iterations);
				sql_stmt := 'DELETE FROM performance_disk WHERE sample_id < ' || trimid || ' AND ROWNUM <= ' || rownum;				
				EXECUTE IMMEDIATE sql_stmt;
				COMMIT;
				i := i + 1;
			END LOOP;

			-- trim performance_disk_total
			i := 0;
			SELECT count(*) INTO samplesnum FROM performance_sample ps, performance_disk_total px WHERE ps.sample_time < trimdate and px.sample_id=ps.id; 
			remainder := mod(samplesnum, rownum);
			iterations := ((samplesnum - remainder)/rownum) + 1;			
			WHILE i < iterations LOOP
				DBMS_OUTPUT.put_line('Trimming performance_disk_total table iteration ' || (i+1) || ' of ' || iterations);
				sql_stmt := 'DELETE FROM performance_disk_total WHERE sample_id < ' || trimid || ' AND ROWNUM <= ' || rownum;				
				EXECUTE IMMEDIATE sql_stmt;
				COMMIT;
				i := i + 1;
			END LOOP;

			-- trim performance_esx3_workload
			i := 0;
			SELECT count(*) INTO samplesnum FROM performance_sample ps, performance_esx3_workload px WHERE ps.sample_time < trimdate and px.sample_id=ps.id; 
			remainder := mod(samplesnum, rownum);
			iterations := ((samplesnum - remainder)/rownum) + 1;			
			WHILE i < iterations LOOP
				DBMS_OUTPUT.put_line('Trimming performance_esx3_workload table iteration ' || (i+1) || ' of ' || iterations);
				sql_stmt := 'DELETE FROM performance_esx3_workload WHERE sample_id < ' || trimid || ' AND ROWNUM <= ' || rownum;				
				EXECUTE IMMEDIATE sql_stmt;
				COMMIT;
				i := i + 1;
			END LOOP;

			-- trim performance_fscap
			i := 0;
			SELECT count(*) INTO samplesnum FROM performance_sample ps, performance_fscap px WHERE ps.sample_time < trimdate and px.sample_id=ps.id; 
			remainder := mod(samplesnum, rownum);
			iterations := ((samplesnum - remainder)/rownum) + 1;			
			WHILE i < iterations LOOP
				DBMS_OUTPUT.put_line('Trimming performance_fscap table iteration ' || (i+1) || ' of ' || iterations);
				sql_stmt := 'DELETE FROM performance_fscap WHERE sample_id < ' || trimid || ' AND ROWNUM <= ' || rownum;				
				EXECUTE IMMEDIATE sql_stmt;
				COMMIT;
				i := i + 1;
			END LOOP;

			-- trim performance_lpar_workload
			i := 0;
			SELECT count(*) INTO samplesnum FROM performance_sample ps, performance_lpar_workload px WHERE ps.sample_time < trimdate and px.sample_id=ps.id; 
			remainder := mod(samplesnum, rownum);
			iterations := ((samplesnum - remainder)/rownum) + 1;			
			WHILE i < iterations LOOP
				DBMS_OUTPUT.put_line('Trimming performance_lpar_workload table iteration ' || (i+1) || ' of ' || iterations);
				sql_stmt := 'DELETE FROM performance_lpar_workload WHERE sample_id < ' || trimid || ' AND ROWNUM <= ' || rownum;				
				EXECUTE IMMEDIATE sql_stmt;
				COMMIT;
				i := i + 1;
			END LOOP;

			-- trim performance_network
			i := 0;
			SELECT count(*) INTO samplesnum FROM performance_sample ps, performance_network px WHERE ps.sample_time < trimdate and px.sample_id=ps.id; 
			remainder := mod(samplesnum, rownum);
			iterations := ((samplesnum - remainder)/rownum) + 1;			
			WHILE i < iterations LOOP
				DBMS_OUTPUT.put_line('Trimming performance_network table iteration ' || (i+1) || ' of ' || iterations);
				sql_stmt := 'DELETE FROM performance_network WHERE sample_id < ' || trimid || ' AND ROWNUM <= ' || rownum;				
				EXECUTE IMMEDIATE sql_stmt;
				COMMIT;
				i := i + 1;
			END LOOP;

			-- trim performance_nrm
			i := 0;
			SELECT count(*) INTO samplesnum FROM performance_sample ps, performance_nrm px WHERE ps.sample_time < trimdate and px.sample_id=ps.id; 
			remainder := mod(samplesnum, rownum);
			iterations := ((samplesnum - remainder)/rownum) + 1;			
			WHILE i < iterations LOOP
				DBMS_OUTPUT.put_line('Trimming performance_nrm table iteration ' || (i+1) || ' of ' || iterations);
				sql_stmt := 'DELETE FROM performance_nrm WHERE sample_id < ' || trimid || ' AND ROWNUM <= ' || rownum;				
				EXECUTE IMMEDIATE sql_stmt;
				COMMIT;
				i := i + 1;
			END LOOP;

			-- trim performance_psinfo
			i := 0;
			SELECT count(*) INTO samplesnum FROM performance_sample ps, performance_psinfo px WHERE ps.sample_time < trimdate and px.sample_id=ps.id; 
			remainder := mod(samplesnum, rownum);
			iterations := ((samplesnum - remainder)/rownum) + 1;			
			WHILE i < iterations LOOP
				DBMS_OUTPUT.put_line('Trimming performance_psinfo table iteration ' || (i+1) || ' of ' || iterations);
				sql_stmt := 'DELETE FROM performance_psinfo WHERE sample_id < ' || trimid || ' AND ROWNUM <= ' || rownum;				
				EXECUTE IMMEDIATE sql_stmt;
				COMMIT;
				i := i + 1;
			END LOOP;

			-- trim performance_vxvol
			i := 0;
			SELECT count(*) INTO samplesnum FROM performance_sample ps, performance_vxvol px WHERE ps.sample_time < trimdate and px.sample_id=ps.id; 
			remainder := mod(samplesnum, rownum);
			iterations := ((samplesnum - remainder)/rownum) + 1;			
			WHILE i < iterations LOOP
				DBMS_OUTPUT.put_line('Trimming performance_vxvol table iteration ' || (i+1) || ' of ' || iterations);
				sql_stmt := 'DELETE FROM performance_vxvol WHERE sample_id < ' || trimid || ' AND ROWNUM <= ' || rownum;				
				EXECUTE IMMEDIATE sql_stmt;
				COMMIT;
				i := i + 1;
			END LOOP;

			-- trim performance_who
			i := 0;
			SELECT count(*) INTO samplesnum FROM performance_sample ps, performance_who px WHERE ps.sample_time < trimdate and px.sample_id=ps.id; 
			remainder := mod(samplesnum, rownum);
			iterations := ((samplesnum - remainder)/rownum) + 1;			
			WHILE i < iterations LOOP
				DBMS_OUTPUT.put_line('Trimming performance_who table iteration ' || (i+1) || ' of ' || iterations);
				sql_stmt := 'DELETE FROM performance_who WHERE sample_id < ' || trimid || ' AND ROWNUM <= ' || rownum;				
				EXECUTE IMMEDIATE sql_stmt;
				COMMIT;
				i := i + 1;
			END LOOP;

			-- trim performance_sample
			i := 0;
			SELECT count(*) INTO samplesnum FROM performance_sample WHERE sample_time < trimdate; 
			remainder := mod(samplesnum, rownum);
			iterations := ((samplesnum - remainder)/rownum) + 1;			
			WHILE i < iterations LOOP
				DBMS_OUTPUT.put_line('Trimming performance_sample table iteration ' || (i+1) || ' of ' || iterations);
				sql_stmt := 'DELETE FROM performance_sample WHERE id < ' || trimid || ' AND ROWNUM <= ' || rownum;				
				EXECUTE IMMEDIATE sql_stmt;
				COMMIT;
				i := i + 1;
			END LOOP;

			-- END PERFORMANCE TABLE TRIM BLOCK


			-- trim erdc_decimal_data
			i := 0;
			SELECT count(*) INTO samplesnum FROM erdc_decimal_data WHERE sampletime < trimdate;
			remainder := mod(samplesnum, rownum);
			iterations := ((samplesnum - remainder)/rownum) + 1;			
			WHILE i < iterations LOOP
				DBMS_OUTPUT.put_line('Trimming erdc_decimal_data table iteration ' || (i+1) || ' of ' || iterations);
				sql_stmt := 'DELETE FROM erdc_decimal_data WHERE (sampletime < ''' || trimdate || ''') AND ROWNUM <= ' || rownum;
				EXECUTE IMMEDIATE sql_stmt;
				COMMIT;
				i := i + 1;
			END LOOP;
						
			-- trim erdc_int_data
			i := 0;
			SELECT count(*) INTO samplesnum FROM erdc_int_data WHERE sampletime < trimdate;
			remainder := mod(samplesnum, rownum);
			iterations := ((samplesnum - remainder)/rownum) + 1;			
			WHILE i < iterations LOOP
				DBMS_OUTPUT.put_line('Trimming erdc_int_data table iteration ' || (i+1) || ' of ' || iterations);
				sql_stmt := 'DELETE FROM erdc_int_data WHERE (sampletime < ''' || trimdate || ''') AND ROWNUM <= ' || rownum;
				EXECUTE IMMEDIATE sql_stmt;
				COMMIT;
				i := i + 1;
			END LOOP;

			-- trim erdc_string_data
			i := 0;
			SELECT count(*) INTO samplesnum FROM erdc_string_data WHERE sampletime < trimdate;
			remainder := mod(samplesnum, rownum);
			iterations := ((samplesnum - remainder)/rownum) + 1;			
			WHILE i < iterations LOOP
				DBMS_OUTPUT.put_line('Trimming erdc_string_data table iteration ' || (i+1) || ' of ' || iterations);
				sql_stmt := 'DELETE FROM erdc_string_data WHERE (sampletime < ''' || trimdate || ''') AND ROWNUM <= ' || rownum;
				EXECUTE IMMEDIATE sql_stmt;
				COMMIT;
				i := i + 1;
			END LOOP;
						
			-- trim ranged_object_value
			i := 0;
			SELECT count(*) INTO samplesnum FROM ranged_object_value WHERE sample_time < trimdate; 
			remainder := mod(samplesnum, rownum);
			iterations := ((samplesnum - remainder)/rownum) + 1;
			WHILE i < iterations LOOP
				DBMS_OUTPUT.put_line('Trimming ranged_object_value table iteration ' || (i+1) || ' of ' || iterations);
				sql_stmt := 'DELETE FROM ranged_object_value WHERE (sample_time < ''' || trimdate || ''') AND ROWNUM <= ' || rownum;
				EXECUTE IMMEDIATE sql_stmt;
				COMMIT;
				i := i + 1;
			END LOOP;			


			EXECUTE IMMEDIATE 'TRUNCATE TABLE archive_delenda';
			COMMIT;	
			
		ELSE
			DBMS_OUTPUT.put_line('No performance data found prior to ' || trimdate || ', skipping DELETEs.  Modify retaindays in script.');					
		END IF;
	END trim_uptime_data;
/
